#!/bin/sh

git clean -fX
autoreconf -i -W all
