bug61_difference_full.i--empty-class(error).re:2:4: error: empty character class
