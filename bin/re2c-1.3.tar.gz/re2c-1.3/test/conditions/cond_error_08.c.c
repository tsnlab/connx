conditions/cond_error_08.c.re:4:3: error: startup code is already defined at line 3
