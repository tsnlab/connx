conditions/cond_error_10.c.re:6:5: error: setup for non existing condition 'c' found
