conditions/cond_error_03.c.re:3:4: error: syntax error
