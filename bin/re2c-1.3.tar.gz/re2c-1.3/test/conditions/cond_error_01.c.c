conditions/cond_error_01.c.re:3:3: error: syntax error
