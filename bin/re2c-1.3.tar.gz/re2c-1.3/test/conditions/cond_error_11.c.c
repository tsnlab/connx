conditions/cond_error_11.c.re:7:5: error: setup for all conditions '<!*>' is illegal if setup for each condition is defined explicitly
