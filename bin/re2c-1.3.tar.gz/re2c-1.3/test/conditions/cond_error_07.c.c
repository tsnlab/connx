conditions/cond_error_07.c.re:3:4: error: syntax error in condition list
