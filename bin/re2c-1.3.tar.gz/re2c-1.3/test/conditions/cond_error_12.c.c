conditions/cond_error_12.c.re:3:4: error: syntax error in condition list
