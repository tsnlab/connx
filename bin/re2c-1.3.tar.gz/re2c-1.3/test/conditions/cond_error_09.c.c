conditions/cond_error_09.c.re:6:5: error: code to setup rule 'a' is already defined at line 5
