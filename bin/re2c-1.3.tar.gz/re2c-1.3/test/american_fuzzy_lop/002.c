american_fuzzy_lop/002.re:1:8: error: unexpected end of input
