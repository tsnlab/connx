american_fuzzy_lop/008.re:2:10: error: conditions are only allowed with '-c', '--conditions' option
