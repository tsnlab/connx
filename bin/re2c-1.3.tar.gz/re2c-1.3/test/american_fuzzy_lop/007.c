american_fuzzy_lop/007.re:2:18: error: missing ending ';' in configuration
