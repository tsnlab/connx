american_fuzzy_lop/003.re:1:8: error: unexpected end of input
