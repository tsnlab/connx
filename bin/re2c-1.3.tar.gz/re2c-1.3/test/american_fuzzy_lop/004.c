american_fuzzy_lop/004.re:1:8: error: syntax error in escape sequence
