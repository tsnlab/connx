bug1529351.re:5:0: error: unexpected end of input
