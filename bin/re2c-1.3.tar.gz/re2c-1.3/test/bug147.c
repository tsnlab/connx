bug147.re:2:10: error: undefined symbol 'name1'
