
. ../../__bench_utils.sh

compile uri simple "-b"
run_all uri simple

