
. ../../__bench_utils.sh

compile uri rfc3986 "-b"
run_all uri rfc3986

