
. ../../__bench_utils.sh

verify http rfc7230
