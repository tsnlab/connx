
. ../../__bench_utils.sh

compile http simple "-b"
run_all http simple

